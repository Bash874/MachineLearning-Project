import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.tree import export_text
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.tree import plot_tree

# Load the dataset
data = pd.read_csv("Dastek_HR_data.csv")

# Select the features and target
features = ["nqf","age","exp_level"]
target = "q_score"


X = data[features]
y = data[target]

# Preprocess the data (label encoding for non-numeric features)
le = preprocessing.LabelEncoder()
X['exp_level'] = le.fit_transform(X['exp_level'])

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and fit a decision tree classifier
clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)

# Define the candidate profiles
candidates = [
    [23, 7, 1],
    [30, 9, 3],
    [60, 8, 3],
    [45, 10, 8],
    [36, 6, 10]
]

# Make predictions for each candidate
predicted_scores = clf.predict(candidates)


# Make predictions on the training and test sets
y_train_pred = clf.predict(X_train)
y_test_pred = clf.predict(X_test)

# Calculate classification accuracy
accuracy_train = accuracy_score(y_train, y_train_pred)
accuracy_test = accuracy_score(y_test, y_test_pred)

print(f"Training Accuracy: {accuracy_train:.2f}")
print(f"Test Accuracy: {accuracy_test:.2f}")

# Plot the decision tree rules
tree_rules = export_text(clf, feature_names=features)
print("Decision Tree Rules:")
print(tree_rules)

# Print the predicted quality scores for each candidate
for i, score in enumerate(predicted_scores):
    print(f"Candidate {i + 1}: Predicted Quality Score = {score}")
    
# Plot the decision tree with rules
plt.figure(figsize=(15, 10))
plot_tree(clf, filled=True, feature_names=features, class_names=[str(cls) for cls in clf.classes_])
plt.title("Decision Tree with Rules")
plt.show()