import pandas as pd

# Load the dataset
data = pd.read_csv("Dastek_HR_data.csv")

# Select the desired attributes and target
columns = ["nqf","age","exp_level"]
desiredTarget = "q_score"

# Create the feature matrix X and the target vector y
X = data[columns]
y = data[desiredTarget]

# Define the split ratio
splitData = 0.8

# Determine the number of samples and features
sampleNum, attributeNum = X.shape

# Determine the size of the training set
trainSize = int(splitData * sampleNum)

# Split the data into training and test sets
X_train, y_train = X[:trainSize], y[:trainSize]
X_test, y_test = X[trainSize:], y[trainSize:]

# Print the sample sizes and feature counts
print(f"Training set shape: {trainSize} samples,{attributeNum} attributes")
print(f"Test set shape: {sampleNum - trainSize} samples,{attributeNum} attributes")