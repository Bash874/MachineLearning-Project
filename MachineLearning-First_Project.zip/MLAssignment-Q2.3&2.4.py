import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Load the dataset
data = pd.read_csv("clustering_datasets.csv")

data = data.fillna(data.mean())
# Select the relevant features for clustering (you might need to adjust this)
X = data[["x", "y"]]

# Standardize the data
scaler = StandardScaler()
XScale = scaler.fit_transform(X)

# Initialize a list to store the cluster variance
clustVariance = []

# Define a range of potential cluster numbers
clustRange = range(2, 16)

# Loop through the potential cluster numbers
for n_clusters in clustRange:
    # Perform K-means clustering
    kmeans = KMeans(n_clusters=n_clusters, random_state=0)
    kmeans.fit(XScale)

    # Calculate the cluster variance
    clustVariance.append(kmeans.inertia_)

# Plot the cluster variance
plt.figure(figsize=(10, 5))

# Subplot 1: Elbow Method Plot
plt.subplot(1, 2, 1)
plt.plot(clustRange, clustVariance, marker="v")
plt.xlabel("Number of Clusters")
plt.ylabel("Cluster Variance")
plt.title("Elbow method finding number of Clusters")
plt.grid(True)

# Find the optimal cluster size (the elbow point)
optClustSize = clustRange[np.argmin(np.diff(clustVariance)) + 1]
plt.axvline(
    x=optClustSize,
    color="red",
    linestyle="-",
    label= f"Optimal Cluster Size: {optClustSize}",
)
plt.legend()


# Subplot 2: Scatter Plot with Optimal Clusters
optKMean = KMeans(n_clusters=optClustSize, random_state=0)
optLabel = optKMean.fit_predict(XScale)

plt.subplot(1, 2, 2)
plt.scatter(XScale[:, 0], XScale[:, 1], c=optLabel, cmap="cool")
plt.xlabel("X")
plt.ylabel("Y")
plt.title(f" {optClustSize} Cluster Plot")

plt.tight_layout()
plt.show()

# Print the optimal cluster size
print(f"Optimal number of clusters is : {optClustSize}")
