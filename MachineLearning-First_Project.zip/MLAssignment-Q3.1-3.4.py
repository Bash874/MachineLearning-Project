import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load the dataset
data = pd.read_csv("real_estate_data.csv")

# Select the relevant features (attributes) and target variable
X = data[['house_age', 'dist_nStation', 'num_cStores', 'lat', 'long']]
y = data['house_p']

# Define the proportion for the split
split_ratio = 0.8

# Determine the number of samples for the training set
sampleNum = len(X)
trainNum = int(split_ratio * sampleNum)

# Split the data into training and test sets
X_train, y_train = X[:trainNum], y[:trainNum]
X_test, y_test = X[trainNum:], y[trainNum:]


# Fit a linear regression model (code from scratch)
def linear_regression_fit(X, y):
    # Add a column of ones for the intercept term
    X = np.column_stack((np.ones(X.shape[0]), X))
    
    # Compute the coefficients (theta) using the normal equation
    theta = np.linalg.inv(X.T @ X) @ X.T @ y
    
    return theta

# Fit the model on the training data
theta = linear_regression_fit(X_train, y_train)

# Write down the linear regression equation
calc = f'y = {" + ".join([f"{theta[i]:.2f}*x{i+1}" for i in range(len(theta))])}'
print(f'Linear Regression Calculation: {calc}')


# Compute the predicted values on training and test data
X_train = np.column_stack((np.ones(X_train.shape[0]), X_train))
X_test = np.column_stack((np.ones(X_test.shape[0]), X_test))

y_train_pred = X_train @ theta
y_test_pred = X_test @ theta

# Calculate the coefficient of determination (R^2) for both sets
def r_squared(y, y_pred):
    y_mean = np.mean(y)
    ss_total = np.sum((y - y_mean) ** 2)
    ss_residual = np.sum((y - y_pred) ** 2)
    r2 = 1 - (ss_residual / ss_total)
    return r2

r2_train = r_squared(y_train, y_train_pred)
r2_test = r_squared(y_test, y_test_pred)

# Goodness of fit curve for training data
plt.scatter(y_train, y_train_pred, color = "lightgreen")
plt.xlabel("Actual Prices")
plt.ylabel("Predicted Prices")
plt.title("Goodness of Fit -Training Data")
plt.show()

# Goodness of fit curve for test data
plt.scatter(y_test, y_test_pred, color = "lightcoral")
plt.xlabel("Actual Prices")
plt.ylabel("Predicted Prices")
plt.title("Goodness of Fit -Test Data")
plt.show()

print(f'R^2 (Training Data): {r2_train:.2f}')
print(f'R^2 (Test Data): {r2_test:.2f}')
