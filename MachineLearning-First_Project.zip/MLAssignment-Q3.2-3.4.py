import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load the dataset
data = pd.read_csv("real_estate_data.csv")

# Select the relevant features (attributes) and target variable
X = data[['house_age', 'dist_nStation', 'num_cStores', 'lat', 'long']]
y = data['house_p']

# Define the proportion for the split
splitData = 0.8

# Determine the number of samples for the training set
sampleNum = len(X)
trainNum = int(splitData * sampleNum)

# Split the data into training and test sets
X_train, y_train = X[:trainNum], y[:trainNum]
X_test, y_test = X[trainNum:], y[trainNum:]


# Fit a linear regression model (code from scratch)
def linear_regression_fit(X, y):
    # Add a column of ones for the intercept term
    ones = np.ones((X.shape[0], 1))
    X_with_intercept = np.hstack((ones, X))

    # Compute X transpose
    X_transpose = X_with_intercept.T

    # Compute the product of X transpose and X
    X_transpose_X = X_transpose.dot(X_with_intercept)

    # Compute the inverse of X transpose_X
    inverse_X_transpose_X = np.linalg.inv(X_transpose_X)

    # Compute the product of X transpose and y
    X_transpose_y = X_transpose.dot(y)

    # Compute the coefficients (theta)
    regressionCoefficients = inverse_X_transpose_X.dot(X_transpose_y)

    return regressionCoefficients

# Fit the model on the training data
regressionCoefficients = linear_regression_fit(X_train, y_train)

# Write down the linear regression equation
calc = f'y = {" + ".join([f"{regressionCoefficients[i]:.2f}*x{i+1}" for i in range(len(regressionCoefficients))])}'
print(f'Linear Regression Calculation: {calc}')
print("-------------------------")

# Compute the predicted values on training and test data
X_train = np.column_stack((np.ones(X_train.shape[0]), X_train))
X_test = np.column_stack((np.ones(X_test.shape[0]), X_test))

y_train_pred = X_train @ regressionCoefficients
y_test_pred = X_test @ regressionCoefficients

# Calculate the coefficient of determination (R^2) for both sets
def r_squared(y, yPred):
    meanVal = np.mean(y)
    totalSum = np.sum((y - meanVal) ** 2)
    residualValue = np.sum((y - yPred) ** 2)
    Coef_R2 = 1 - (residualValue / totalSum)
    return Coef_R2

r2Train = r_squared(y_train, y_train_pred)
r2Test = r_squared(y_test, y_test_pred)

# Goodness of fit curve for training data
plt.scatter(y_train, y_train_pred, color = "lightgreen")
plt.xlabel("Actual Prices")
plt.ylabel("Predicted Prices")
plt.title("Goodness of Fit -Training Data")
plt.show()

# Goodness of fit curve for test data
plt.scatter(y_test, y_test_pred, color = "lightcoral")
plt.xlabel("Actual Prices")
plt.ylabel("Predicted Prices")
plt.title("Goodness of Fit - Test Data")
plt.show()

print(f"Coefficient of determination(Training Data) = {r2Train:.2f}")
print(f"Coefficient of determination(Test Data) = {r2Test:.2f}")
